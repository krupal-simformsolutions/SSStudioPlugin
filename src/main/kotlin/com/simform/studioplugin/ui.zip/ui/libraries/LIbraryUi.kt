package com.simform.studioplugin.ui.libraries

import com.simform.studioplugin.model.LibraryModel
import javax.swing.JEditorPane
import javax.swing.JList
import javax.swing.JPanel
import javax.swing.JTabbedPane

class LIbraryUi {

    lateinit var jpanel: JPanel
    lateinit var PanelMain: JPanel
    lateinit var editorpane: JEditorPane
    lateinit var panelweb: JPanel
    lateinit var tabbedPane: JTabbedPane
}