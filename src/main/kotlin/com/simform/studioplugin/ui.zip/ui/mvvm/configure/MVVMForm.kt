package com.simform.studioplugin.ui.mvvm.configure

import javax.swing.JPanel
import javax.swing.JTextArea

class MVVMForm {
    lateinit var activityTemplate: JTextArea
    lateinit var fragmentTemplate: JTextArea
    lateinit var viewModelTemplate: JTextArea
    lateinit var layoutTemplate: JTextArea
    lateinit var mainPanel: JPanel
}