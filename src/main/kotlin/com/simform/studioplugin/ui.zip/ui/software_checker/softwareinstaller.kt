package com.simform.studioplugin.ui.software_checker

import javax.swing.JButton
import javax.swing.JLabel
import javax.swing.JPanel

class softwareinstaller {
    lateinit var mainpanel: JPanel
    lateinit var btnInstallPython: JButton
    lateinit var btnInstallCookie: JButton
    lateinit var lblPython: JLabel
    lateinit var lblCookieCutter: JLabel
    lateinit var lblFlutterStatus: JLabel
    lateinit var lblFlutter: JLabel
    lateinit var btnFlutterInstall: JButton
    lateinit var btnContinue: JButton
}