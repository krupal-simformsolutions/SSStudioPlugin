package com.simform.studioplugin

import javax.swing.JButton
import javax.swing.JPanel
import javax.swing.JTextField


class KeyStoreInoUi {
    lateinit var mainpanel: JPanel
    lateinit var tfKeyPass: JTextField
    lateinit var tfAlias: JTextField
    lateinit var tfKeyStore: JTextField
    lateinit var tfStorePass: JTextField
    lateinit var btnGenerate: JButton
    lateinit var btnBrowse: JButton
    lateinit var tfMd5: JTextField
    lateinit var tfSha1: JTextField
    lateinit var tfSha256: JTextField
    lateinit var btnMd5Copy:JButton
    lateinit var btnSha1Copy:JButton
    lateinit var btnSha256Copy:JButton




    init {


    }

}